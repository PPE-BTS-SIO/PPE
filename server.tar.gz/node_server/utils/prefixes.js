module.exports = {
	socketIO: `${'['.white}${'Socket.io'.yellow}${']'.white}`,
	mysql: `${'['.white}${'MySQL'.yellow}${']'.white}`,
	pdf: `${'['.white}${'PDF'.yellow}${']'.white}`
}
